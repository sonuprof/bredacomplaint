<?php

namespace App\Imports;

use App\Models\Bcsakhitransaction;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;
use Log;

class bc_transaction_import implements ToModel, WithStartRow
{
  
    private $month;
    

    public function __construct($month)
    {
        $this->month = $month;
    }
    /**
     * 
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
    //    dd($row);
        return new Bcsakhitransaction([
            'bcsakhi_id' => $row[0],
            'bc_sakhi' => $row[1],
            'new_enroll' => $row[2],
            'no_acc_verified_cbs' => $row[3],
            'total_deposit_amt' => $row[4],
            'deposit_total_transctn' => $row[5],
            'aeps_deposit_amt' => $row[6],
            'aeps_total_transctn' => $row[7],
            'aeps_acquirer_amt' => $row[8],
            'acquirer_aeps_total_transctn' => $row[9],
            'deposit_amt_shg' => $row[9],
            'total_shg_deposit_trans' => $row[11],
            'total_widrawl_amt' => $row[12],
            'total_no_withdral_trans' => $row[13],
            'rupay_widrawl_amt' => $row[14],
            'no_rupay_widrawl_trans' => $row[15], 
            'aeps_onus_widrawl_amt' => $row[16],
            'no_aeps_onus_widrawl_trans' => $row[17],
            'aeps_acq_widrawl_amt_of' => $row[18],
            'no_aeps_acq_widrawl_trans_on' => $row[19],
            'shg_widrawl_amt' => $row[20],
            'no_shg_widrawl_trans' => $row[21],
            't_f_t_amt' => $row[22],
            't_f_t_trans' => $row[23],
            'aeps_fund_tnsfer_amt_on' => $row[24],
            'aeps_fund_tnsfer_trans_on' => $row[25],
            'aeps_acq_fund_tnsfer_amt_of' => $row[26],
            'aeps_acq_fund_tnsfer_trans_of' => $row[27],                
            'i_m_t_amt' => $row[28], 
            'i_m_t_trans_no' => $row[29],
            'shg_fund_tnsfr_amt' => $row[30],
            'no_shg_fund_tnsfr_trans' => $row[31],
            'pmjjy_cnt' => $row[32],
            'pmsby_cnt' => $row[33],
            'cnt_sccess_uid' => $row[34],
            'other_service' => $row[35],
            'total_txn_count' => $row[36],
            'total_txn_amt' => $row[37],
            'earng_bc' => $row[38],
            
            'upload_month' => $this->month,
            
        ]);
    }
    public function startRow(): int
    {
        return 2; // Start from row 2 (skip the header row)
    }
}
