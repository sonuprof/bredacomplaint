<?php

namespace App\Imports;

use App\Models\bcsakhi;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;


class BCsakhiImport implements ToModel,WithStartRow
{
  
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new bcsakhi([
            'name'     => $row[0],
            'designation'    => $row[1],
            'contact'    => $row[2], 
            'parent_shg'    => $row[3],
            'village'    => $row[4],
            'bank_name'    => $row[5],
            'branch_name'    => $row[6],
            'branch_code'    => $row[7],
            'block'    => $row[8],
            'block_type'    => $row[9],
            'district'    => $row[10],
            'corporate_bc'    => $row[11],
            'agent_id'    => $row[12],
            'date_code_creation'    => $row[13],
            'iibf_certificate'    => $row[14],
            'model'    => $row[15],
            'machine_id'    => $row[16],
            'no_village'    => $row[17],
            'no_shg'    => $row[18],
            'od_limit'    => $row[19],
            'settlement_account'    => $row[20],
            'created_by'    => 11,
            'date'    => $row[21],
            // 'upload_month'    =>  $this->month ,

        ]);
    }
    public function startRow(): int
    {
        return 2; // Start from row 2 (skip the header row)
    }
}
