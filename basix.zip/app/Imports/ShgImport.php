<?php

namespace App\Imports;

use App\Models\Shg;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;
class ShgImport implements ToModel
{
    /**
     * @return int
     */
    public function startRow(): int
    {
        return 2; // Skip the first row (header row)
    }

    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
   
    public function model(array $row)
{
   
    // Check if the current row is not the header row
    if ($this->getRowIndex() >= 2) {
        return new Shg([
            'state' => $row[0],
            'district' => $row[1],
            'block' => $row[2],
            'mclf' => $row[3],
            'clf_code' => $row[4],
            'clf_name' => $row[5],
            'da' => $row[6],
            'clf_bank' => $row[7],
            'clf_block' => $row[8],
            'clf_ifs_code' => $row[9],
            'clf_acc_no' => $row[10],
            'vo_name' => $row[11],
            'vo_mis_code' => $row[12],
            'vo_bank' => $row[13], 
            'vo_branch_name' => $row[14],
            'vo_ifs_code' => $row[15],
             'vo_acc_no' => $row[16],
            'shg_name' => $row[17],
            'shg_code' => $row[18],
            'shg_bank' => $row[19],
            'shg_branch' => $row[20],
            'shg_ifs_code' => $row[21],
            'shg_acc_no' => $row[22],
            'bcsakhi_name' => $row[23],
            'bcsakhi_bank' => $row[24],
            'bcsakhi_ifs_code' => $row[25],
            'bcsakhi_block' => $row[26], 
            'bcsakhi_district' => $row[27],
            'bcsakhi_contact' => $row[28],
            'Shortlisted_dual_auth_drive' => $row[29],
            'form_sbmtd_bank' => $row[30],
            'clf_d_a_activated' => $row[31],
            'vo_d_a_activated' => $row[32],
            'shg_d_a_activated' => $row[33],
            'transaction_status' => $row[34],
             'remarks' => $row[35],
            'created_by' => 111,
        ]);
    }
    
    // If it's the header row, return null to skip saving it in the database
    return null;
}

private $rowIndex = 1;

// Custom method to keep track of the row index
private function getRowIndex()
{
    return $this->rowIndex++;
}

}
