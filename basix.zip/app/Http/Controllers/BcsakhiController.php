<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\bcsakhi;
use App\Models\Bcsakhitransaction;

use App\Imports\BCsakhitransactionImport;
use App\Imports\bc_transaction_import;

use App\Imports\BCsakhiImport;

use Maatwebsite\Excel\Facades\Excel;
use DB;
use DateTime;

class BcsakhiController extends Controller
{
  public function dashboard(Request $request){
     $data['total_txn_amt'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');
    $data['total_txn_count'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
    $data['total_bc'] = DB::table('bcsakhis')->select('bc_type')->count();
    $data['bc_active'] = DB::table('bcsakhitransactions')->where('total_txn_count', '>=', 1 )->select('bc_type')->count();
    $data['bcamount'] = DB::select("SELECT `bcsakhis`.`name`,`bcsakhis`.`block`,`bcsakhis`.`district`, SUM(`bcsakhitransactions`.`total_txn_amt`) AS 'total_txn_amt' FROM `bcsakhis`,`bcsakhitransactions` WHERE `bcsakhis`.`id` = `bcsakhitransactions`.`bcsakhi_id` GROUP BY `bcsakhis`.`name`, bcsakhis.block, bcsakhis.district ORDER BY total_txn_amt DESC LIMIT 10");
    $data['district'] = bcsakhi::select('bcsakhis.district', DB::raw('SUM(bcsakhitransactions.total_txn_amt) as total_amount'))
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->groupBy('bcsakhis.district')->orderBy('total_amount', 'desc')->take(10)
    ->get();
      $data['block'] = bcsakhi::select('bcsakhis.block', DB::raw('SUM(bcsakhitransactions.total_txn_amt) as total_amount'))
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')->where('block', '!=', '#N/A')
    ->groupBy('bcsakhis.block')->orderBy('total_amount', 'desc')->take(10)
    ->get();
    $data['bc_shg'] = DB::select("SELECT bc_sakhi, (total_shg_deposit_trans + no_shg_widrawl_trans + shg_fund_tnsfr_amt) AS total_shg_trans FROM bcsakhitransactions ORDER BY total_shg_trans DESC LIMIT 10");

    $data['district_cnt'] = DB::table('bcsakhis')->distinct('district')->count();
    $data['block_cnt'] = DB::table('bcsakhis')->distinct('block')->count();
    $data['village_cnt'] = DB::table('bcsakhis')->distinct('village')->count();
    $data['bank_cnt'] = DB::table('bcsakhis')->distinct('bank_name')->where('model', 'KIOSK')->count();
    $data['bcsakhi_cnt'] = DB::table('bcsakhis')->distinct('agent_id')->count();
    $data['corporate_bcsakhi_cnt'] = DB::table('bcsakhis')->distinct('corporate_bc')->count();
    $data['full_fledged'] = DB::table('bcsakhis')->where('designation', 'BC')->count('designation');
    $data['digipay'] = DB::table('bcsakhis')->where('designation', 'DG')->count('designation');
    $data['pay_point'] = DB::table('bcsakhis')->where('designation', 'PP')->count('designation');
    $data['total_comm'] = DB::table('bcsakhitransactions')->sum('earng_bc');
    $data['pmjjy_sum'] = DB::table('bcsakhitransactions')->sum('pmjjy_cnt');
    $data['pmsby_sum'] = DB::table('bcsakhitransactions')->sum('pmsby_cnt');
    $data['iibf_certified'] = DB::table('bcsakhis')->select('iibf_certificate')->where('iibf_certificate','Y')->count();
    $data['apy_sum'] = DB::table('bcsakhitransactions')->sum('other_service');
    $data['earning_bc'] = DB::table('bcsakhitransactions')->sum('earng_bc');
    $shg_trans1 = DB::table('bcsakhitransactions')->sum('total_shg_deposit_trans');
    $shg_trans2 = DB::table('bcsakhitransactions')->sum('no_shg_widrawl_trans');
    $shg_trans3 = DB::table('bcsakhitransactions')->sum('no_shg_fund_tnsfr_trans');
    $data['shg_trans'] = $shg_trans1 + $shg_trans2  + $shg_trans3;
    $shg_amt1 = DB::table('bcsakhitransactions')->sum('shg_deposit_amt');
    $shg_amt2 = DB::table('bcsakhitransactions')->sum('shg_widrawl_amt');
    $shg_amt3 = DB::table('bcsakhitransactions')->sum('shg_fund_tnsfr_amt');
    $data['shg_amt'] = $shg_amt1 + $shg_amt2  + $shg_amt3;
    $data['account_open'] = DB::table('bcsakhitransactions')->sum('new_enroll');
    
      $data['code_dashboard'] = DB::table('bcsakhitransactions')
    ->join('bcsakhis', 'bcsakhitransactions.bcsakhi_id', '=', 'bcsakhis.id')
    ->select(
        DB::raw('SUM(total_txn_amt) as total_txn_amt'),
        DB::raw('SUM(total_txn_count) as total_txn_count'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) as total_txn_count2'),
        DB::raw('COUNT(bcsakhis.bc_type) as total_bc'),
        DB::raw('COUNT(CASE WHEN total_txn_count >= 1 THEN 1 ELSE NULL END) as bc_active'),
        DB::raw('SUM(total_shg_deposit_trans + no_shg_widrawl_trans + no_shg_fund_tnsfr_trans) as shg_trans'),
        DB::raw('SUM(shg_deposit_amt + shg_widrawl_amt + shg_fund_tnsfr_amt) as shg_amt'),
        DB::raw('COUNT(DISTINCT bcsakhis.district) as district_cnt'),
        DB::raw('COUNT(DISTINCT bcsakhis.block) as block_cnt'),
        DB::raw('COUNT(DISTINCT bcsakhis.village) as village_cnt'),
        DB::raw('COUNT(DISTINCT CASE WHEN bcsakhis.model = "KIOSK" THEN bcsakhis.bank_name ELSE NULL END) as bank_cnt'),
        DB::raw('COUNT(bcsakhis.agent_id) as bcsakhi_cnt'),
        DB::raw('COUNT(DISTINCT bcsakhis.corporate_bc) as corporate_bcsakhi_cnt'),
        DB::raw('COUNT(CASE WHEN bcsakhis.designation = "BC" THEN bcsakhis.designation ELSE NULL END) as full_fledged'),
        DB::raw('COUNT(CASE WHEN bcsakhis.designation = "DG" THEN bcsakhis.designation ELSE NULL END) as digipay'),
        DB::raw('COUNT(CASE WHEN bcsakhis.designation = "PP" THEN bcsakhis.designation ELSE NULL END) as pay_point'),
        DB::raw('SUM(earng_bc) as total_comm'),
        DB::raw('SUM(pmjjy_cnt) as pmjjy_sum'),
        DB::raw('SUM(pmsby_cnt) as pmsby_sum'),
        DB::raw('COUNT(CASE WHEN bcsakhis.iibf_certificate = "Y" THEN 1 ELSE NULL END) as iibf_certified'),
        DB::raw('SUM(other_service) as apy_sum'),
        DB::raw('SUM(earng_bc) as earning_bc'),
        DB::raw('SUM(new_enroll) as account_open')
    )
    ->get();
    
    return view('pages.dashboard',$data);
  }
  
  
    public function filter_dashboard(Request $request)
  {

    $data['month']= DB::table('bcsakhitransactions')->select('month')->distinct()->get();
    $block_type = $request->block_type;
     $month = $request->input('month'); // Assuming you have a form field named 'month' in your HTML form

    if ($request->isMethod('post')) {

      if ($block_type == 'NRLM' ||  $block_type == 'NRETP') {

          $data['code_dashboard'] = DB::table('bcsakhitransactions')
          ->join('bcsakhis', 'bcsakhitransactions.bcsakhi_id', '=', 'bcsakhis.id')
          ->where('bcsakhis.block_type', '=', $block_type)
          ->select(
              DB::raw('SUM(total_txn_amt) as total_txn_amt'),
              DB::raw('SUM(total_txn_count) as total_txn_count'),
              DB::raw('SUM(bcsakhitransactions.total_txn_count) as total_txn_count2'),
              DB::raw('COUNT(bcsakhis.bc_type) as total_bc'),
              DB::raw('COUNT(CASE WHEN total_txn_count >= 1 THEN 1 ELSE NULL END) as bc_active'),
              DB::raw('SUM(total_shg_deposit_trans + no_shg_widrawl_trans + no_shg_fund_tnsfr_trans) as shg_trans'),
              DB::raw('SUM(shg_deposit_amt + shg_widrawl_amt + shg_fund_tnsfr_amt) as shg_amt'),
              DB::raw('COUNT(DISTINCT bcsakhis.district) as district_cnt'),
              DB::raw('COUNT(DISTINCT bcsakhis.block) as block_cnt'),
              DB::raw('COUNT(DISTINCT bcsakhis.village) as village_cnt'),
              DB::raw('COUNT(DISTINCT CASE WHEN bcsakhis.model = "KIOSK" THEN bcsakhis.bank_name ELSE NULL END) as bank_cnt'),
              DB::raw('COUNT(bcsakhis.agent_id) as bcsakhi_cnt'),
              DB::raw('COUNT(DISTINCT bcsakhis.corporate_bc) as corporate_bcsakhi_cnt'),
              DB::raw('COUNT(CASE WHEN bcsakhis.designation = "BC" THEN bcsakhis.designation ELSE NULL END) as full_fledged'),
              DB::raw('COUNT(CASE WHEN bcsakhis.designation = "DG" THEN bcsakhis.designation ELSE NULL END) as digipay'),
              DB::raw('COUNT(CASE WHEN bcsakhis.designation = "PP" THEN bcsakhis.designation ELSE NULL END) as pay_point'),
              DB::raw('SUM(earng_bc) as total_comm'),
              DB::raw('SUM(pmjjy_cnt) as pmjjy_sum'),
              DB::raw('SUM(pmsby_cnt) as pmsby_sum'),
              DB::raw('COUNT(CASE WHEN bcsakhis.iibf_certificate = "Y" THEN 1 ELSE NULL END) as iibf_certified'),
              DB::raw('SUM(other_service) as apy_sum'),
              DB::raw('SUM(earng_bc) as earning_bc'),
              DB::raw('SUM(new_enroll) as account_open')
          )
          ->get();


        // dd($data);

      } else {

   
        $data['code_dashboard'] = DB::table('bcsakhitransactions')
        ->join('bcsakhis', 'bcsakhitransactions.bcsakhi_id', '=', 'bcsakhis.id')
        ->select(
            DB::raw('SUM(total_txn_amt) as total_txn_amt'),
            DB::raw('SUM(total_txn_count) as total_txn_count'),
            DB::raw('SUM(bcsakhitransactions.total_txn_count) as total_txn_count2'),
            DB::raw('COUNT(bcsakhis.bc_type) as total_bc'),
            DB::raw('COUNT(CASE WHEN total_txn_count >= 1 THEN 1 ELSE NULL END) as bc_active'),
            DB::raw('SUM(total_shg_deposit_trans + no_shg_widrawl_trans + no_shg_fund_tnsfr_trans) as shg_trans'),
            DB::raw('SUM(shg_deposit_amt + shg_widrawl_amt + shg_fund_tnsfr_amt) as shg_amt'),
            DB::raw('COUNT(DISTINCT bcsakhis.district) as district_cnt'),
            DB::raw('COUNT(DISTINCT bcsakhis.block) as block_cnt'),
            DB::raw('COUNT(DISTINCT bcsakhis.village) as village_cnt'),
            DB::raw('COUNT(DISTINCT CASE WHEN bcsakhis.model = "KIOSK" THEN bcsakhis.bank_name ELSE NULL END) as bank_cnt'),
            DB::raw('COUNT(bcsakhis.agent_id) as bcsakhi_cnt'),
            DB::raw('COUNT(DISTINCT bcsakhis.corporate_bc) as corporate_bcsakhi_cnt'),
            DB::raw('COUNT(CASE WHEN bcsakhis.designation = "BC" THEN bcsakhis.designation ELSE NULL END) as full_fledged'),
            DB::raw('COUNT(CASE WHEN bcsakhis.designation = "DG" THEN bcsakhis.designation ELSE NULL END) as digipay'),
            DB::raw('COUNT(CASE WHEN bcsakhis.designation = "PP" THEN bcsakhis.designation ELSE NULL END) as pay_point'),
            DB::raw('SUM(earng_bc) as total_comm'),
            DB::raw('SUM(pmjjy_cnt) as pmjjy_sum'),
            DB::raw('SUM(pmsby_cnt) as pmsby_sum'),
            DB::raw('COUNT(CASE WHEN bcsakhis.iibf_certificate = "Y" THEN 1 ELSE NULL END) as iibf_certified'),
            DB::raw('SUM(other_service) as apy_sum'),
            DB::raw('SUM(earng_bc) as earning_bc'),
            DB::raw('SUM(new_enroll) as account_open')
        )
        ->get();
      }
    } else {

   
      $data['code_dashboard'] = DB::table('bcsakhitransactions')
      ->join('bcsakhis', 'bcsakhitransactions.bcsakhi_id', '=', 'bcsakhis.id')
      ->select(
          DB::raw('SUM(total_txn_amt) as total_txn_amt'),
          DB::raw('SUM(total_txn_count) as total_txn_count'),
          DB::raw('SUM(bcsakhitransactions.total_txn_count) as total_txn_count2'),
          DB::raw('COUNT(bcsakhis.bc_type) as total_bc'),
          DB::raw('COUNT(CASE WHEN total_txn_count >= 1 THEN 1 ELSE NULL END) as bc_active'),
          DB::raw('SUM(total_shg_deposit_trans + no_shg_widrawl_trans + no_shg_fund_tnsfr_trans) as shg_trans'),
          DB::raw('SUM(shg_deposit_amt + shg_widrawl_amt + shg_fund_tnsfr_amt) as shg_amt'),
          DB::raw('COUNT(DISTINCT bcsakhis.district) as district_cnt'),
          DB::raw('COUNT(DISTINCT bcsakhis.block) as block_cnt'),
          DB::raw('COUNT(DISTINCT bcsakhis.village) as village_cnt'),
          DB::raw('COUNT(DISTINCT CASE WHEN bcsakhis.model = "KIOSK" THEN bcsakhis.bank_name ELSE NULL END) as bank_cnt'),
          DB::raw('COUNT(bcsakhis.agent_id) as bcsakhi_cnt'),
          DB::raw('COUNT(DISTINCT bcsakhis.corporate_bc) as corporate_bcsakhi_cnt'),
          DB::raw('COUNT(CASE WHEN bcsakhis.designation = "BC" THEN bcsakhis.designation ELSE NULL END) as full_fledged'),
          DB::raw('COUNT(CASE WHEN bcsakhis.designation = "DG" THEN bcsakhis.designation ELSE NULL END) as digipay'),
          DB::raw('COUNT(CASE WHEN bcsakhis.designation = "PP" THEN bcsakhis.designation ELSE NULL END) as pay_point'),
          DB::raw('SUM(earng_bc) as total_comm'),
          DB::raw('SUM(pmjjy_cnt) as pmjjy_sum'),
          DB::raw('SUM(pmsby_cnt) as pmsby_sum'),
          DB::raw('COUNT(CASE WHEN bcsakhis.iibf_certificate = "Y" THEN 1 ELSE NULL END) as iibf_certified'),
          DB::raw('SUM(other_service) as apy_sum'),
          DB::raw('SUM(earng_bc) as earning_bc'),
          DB::raw('SUM(new_enroll) as account_open')
      )
      ->get();
    }


    $data['total_txn_amt'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');
    $data['total_txn_amt2'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');
   $data['total_txn_count'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
   $data['total_txn_count2'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
   $data['total_bc'] = DB::table('bcsakhis')->select('bc_type')->count();
   $data['bc_active'] = DB::table('bcsakhitransactions')
   ->where('total_txn_count', '>', 0)
   ->count();
   $data['bcamount'] = DB::select("SELECT `bcsakhis`.`name`,`bcsakhis`.`block`,`bcsakhis`.`district`, SUM(`bcsakhitransactions`.`total_txn_amt`) AS 'total_txn_amt' FROM `bcsakhis`,`bcsakhitransactions` WHERE `bcsakhis`.`id` = `bcsakhitransactions`.`bcsakhi_id` GROUP BY `bcsakhis`.`name`, bcsakhis.block, bcsakhis.district ORDER BY total_txn_amt DESC LIMIT 10");
   $data['district'] = bcsakhi::select('bcsakhis.district', DB::raw('SUM(bcsakhitransactions.total_txn_amt) as total_amount'))
   ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
   ->groupBy('bcsakhis.district')->orderBy('total_amount', 'desc')->take(10)
   ->get();
     $data['block'] = bcsakhi::select('bcsakhis.block', DB::raw('SUM(bcsakhitransactions.total_txn_amt) as total_amount'))
   ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')->where('block', '!=', '#N/A')
   ->groupBy('bcsakhis.block')->orderBy('total_amount', 'desc')->take(10)
   ->get();
   $data['bc_shg'] = DB::select("SELECT bc_sakhi, (total_shg_deposit_trans + no_shg_widrawl_trans + shg_fund_tnsfr_amt) AS total_shg_trans FROM bcsakhitransactions ORDER BY total_shg_trans DESC LIMIT 10");

   $data['district_cnt'] = DB::table('bcsakhis')->distinct('district')->count();
   $data['block_cnt'] = DB::table('bcsakhis')->distinct('block')->count();
   $data['village_cnt'] = DB::table('bcsakhis')->distinct('village')->count();
   $data['bank_cnt'] = DB::table('bcsakhis')->distinct('bank_name')->where('model', 'KIOSK')->count();
   $data['bcsakhi_cnt'] = DB::table('bcsakhis')->distinct('agent_id')->count();
   $data['corporate_bcsakhi_cnt'] = DB::table('bcsakhis')->distinct('corporate_bc')->count();
   $data['full_fledged'] = DB::table('bcsakhis')->where('designation', 'BC')->count('designation');
   $data['digipay'] = DB::table('bcsakhis')->where('designation', 'DG')->count('designation');
   $data['pay_point'] = DB::table('bcsakhis')->where('designation', 'PP')->count('designation');
   $data['total_comm'] = DB::table('bcsakhitransactions')->sum('earng_bc');
   $data['pmjjy_sum'] = DB::table('bcsakhitransactions')->sum('pmjjy_cnt');
   $data['pmsby_sum'] = DB::table('bcsakhitransactions')->sum('pmsby_cnt');
   $data['iibf_certified'] = DB::table('bcsakhis')->select('iibf_certificate')->where('iibf_certificate','Y')->count();
   $data['apy_sum'] = DB::table('bcsakhitransactions')->sum('other_service');
   $data['earning_bc'] = DB::table('bcsakhitransactions')->sum('earng_bc');
   $shg_trans1 = DB::table('bcsakhitransactions')->sum('total_shg_deposit_trans');
   $shg_trans2 = DB::table('bcsakhitransactions')->sum('no_shg_widrawl_trans');
   $shg_trans3 = DB::table('bcsakhitransactions')->sum('no_shg_fund_tnsfr_trans');
   $data['shg_trans'] = $shg_trans1 + $shg_trans2  + $shg_trans3;
   $shg_amt1 = DB::table('bcsakhitransactions')->sum('shg_deposit_amt');
   $shg_amt2 = DB::table('bcsakhitransactions')->sum('shg_widrawl_amt');
   $shg_amt3 = DB::table('bcsakhitransactions')->sum('shg_fund_tnsfr_amt');
   $data['shg_amt'] = $shg_amt1 + $shg_amt2  + $shg_amt3;
   $data['account_open'] = DB::table('bcsakhitransactions')->sum('new_enroll');
    return view('pages.dashboard', $data);
  }
  
      public function add_bcsakhi(Request $request){
        return view('bcsakhi.add-bcsakhi');
      }
      public function add_bcsakhi_transaction(Request $request){
        return view('bcsakhi.bcsakhi-transaction');
      }
      public function add_bcsakhiimport_transaction(Request $request){
        return view('bcsakhi.import-bcsakhi-txn');
      }
      public function bcsakhi_import_transaction(Request $request){
                      
        $dateTime = new DateTime($request->month);
        $month = date_format($dateTime, "F Y");
            $filePath = $request->file('Transaction')->store('files');

    Excel::import(new bc_transaction_import($month), $filePath);

    return back()->with('status', 'Data Imported Successfully');
        
        
     
    }
          public function view_import_bcsakhi()
{
  return  view ('bcsakhi.view-import-bcsakhi');
}


      public function view_bcsakhi(Request $request){
        
        $data['bcsakhi'] = DB::table('bcsakhis')->limit(60)->get();
        $data['bc_district'] = DB::table('bcsakhis')->select('district')->distinct()->get();
        return view('bcsakhi.view-bcsakhi', $data);
      }
      public function view_bcsakhi_transaction(Request $request){
        $data['bcsakhi'] = DB::table('bcsakhitransactions')->limit(15)->get();
        $data['bc_district'] = DB::table('bcsakhis')->select('district')->distinct()->get();
        return view('bcsakhi.view-bcsakhi-transaction', $data);
      }

      public function bcsakhiimport(Request $request){

      
        // $month = $request->input('month');

        // Pass the 'month' value to the BCsakhiImport class
        Excel::import(new BCsakhiImport, $request->file('bcsakhiexcel')->store('files'));
    
       return back()->with('status', 'Data imported successfully');
       }

      public function create(Request $request)
    {
    
            $validator = $request->validate([
            'name' => 'required|min:5|max:50|unique:bcsakhis',
        ]);
      
           $bcsakhi = new Bcsakhi();
        
           $bcsakhi->name = $request->name;

           $bcsakhi->designation  = $request->designation ;
           $bcsakhi->contact  = $request->contact;
           $bcsakhi->parent_shg = $request->parent_shg;
           $bcsakhi->village = $request->village;
           $bcsakhi->bank_name = $request->bank_name;
           $bcsakhi->branch_name = $request->branch_name;
           $bcsakhi->branch_code  = $request->branch_code ;
           $bcsakhi->block  = $request->block;
           $bcsakhi->block_type  = $request->block_type;
           $bcsakhi->district  = $request->district ;
           $bcsakhi->corporate_bc  = $request->corporate_bc ;
           $bcsakhi->agent_id  = $request->agent_id ;
           $bcsakhi->date_code_creation  = $request->date_code_creation ;
           $bcsakhi->iibf_certificate  = $request->iibf_certificate ;
           $bcsakhi->model  = $request->model ;
           $bcsakhi->machine_id  = $request->machine_id ;
           $bcsakhi->no_village  = $request->no_village ;
           $bcsakhi->no_shg  = $request->no_shg ;
           $bcsakhi->od_limit = $request->od_limit ;
           $bcsakhi->settlement_account  = $request->settlement_account ;
           $bcsakhi->created_by  = $request->created_by ;
           $bcsakhi->date = $request->date;
           $bcsakhi->save();
           return back()->with('status', 'Bcsakhi Added Successfully');
    }
  

    public function save(Request $request)
   {
       
          $Bc = new Bcsakhitransaction();  
          $Bc->bcsakhi_id =$request->bcsakhi_id;
          $Bc->month = $request->month;
         $Bc->bc_sakhi = $request->bc_sakhi;
         $Bc->new_enroll  = $request->new_enroll ;
         $Bc->no_acc_verified_cbs  = $request->no_acc_verified_cbs;
         $Bc->total_deposit_amt = $request->total_deposit_amt;
         $Bc->deposit_total_transctn = $request->deposit_total_transctn;
         $Bc->aeps_deposit_amt = $request->aeps_deposit_amt;
         $Bc->aeps_total_transctn = $request->aeps_total_transctn;
         $Bc->aeps_acquirer_amt  = $request->aeps_acquirer_amt ;
         $Bc->acquirer_aeps_total_transctn  = $request->acquirer_aeps_total_transctn;
         $Bc->shg_deposit_amt  = $request->shg_deposit_amt;
         $Bc->total_shg_deposit_trans  = $request->total_shg_deposit_trans ;
         $Bc->total_widrawl_amt  = $request->total_widrawl_amt ;
         $Bc->total_no_withdral_trans  = $request->total_no_withdral_trans ;
         $Bc->rupay_widrawl_amt  = $request->rupay_widrawl_amt ;
         $Bc->no_rupay_widrawl_trans  = $request->no_rupay_widrawl_trans ;
         $Bc->aeps_onus_widrawl_amt  = $request->aeps_onus_widrawl_amt ;
         $Bc->no_aeps_onus_widrawl_trans  = $request->no_aeps_onus_widrawl_trans ;
         $Bc->aeps_acq_widrawl_amt_of  = $request->aeps_acq_widrawl_amt_of ;
         $Bc->no_aeps_acq_widrawl_trans_on  = $request->no_aeps_acq_widrawl_trans_on ;
         $Bc->shg_widrawl_amt = $request->shg_widrawl_amt ;
         $Bc->no_shg_widrawl_trans  = $request->no_shg_widrawl_trans ;
         $Bc->t_f_t_amt  = $request->t_f_t_amt ;
         $Bc->t_f_t_trans = $request->t_f_t_trans;
         $Bc->aeps_fund_tnsfer_amt_on  = $request->aeps_fund_tnsfer_amt_on ;
         $Bc->aeps_fund_tnsfer_trans_on  = $request->aeps_fund_tnsfer_trans_on ;
         $Bc->aeps_acq_fund_tnsfer_amt_of = $request->aeps_acq_fund_tnsfer_amt_of ;
         $Bc->aeps_acq_fund_tnsfer_trans_of  = $request->aeps_acq_fund_tnsfer_trans_of;
         $Bc->i_m_t_amt  = $request->i_m_t_amt ;
         $Bc->i_m_t_trans_no = $request->i_m_t_trans_no;
           $Bc->no_shg_fund_tnsfr_trans = $request->no_shg_fund_tnsfr_trans;
         $Bc->pmjjy_cnt = $request->pmjjy_cnt;
         $Bc->pmsby_cnt = $request->pmsby_cnt;
         $Bc->cnt_sccess_uid = $request->cnt_sccess_uid;
         $Bc->other_service = $request->other_service;
         $Bc->total_txn_count = $request->total_txn_count;
         $Bc->total_txn_amt = $request->total_txn_amt;   
       $Bc->earng_bc = $request->earng_bc;

        //   $shg->created_by = 111;Tansaction
          $Bc->save();
          return back()->with('status', 'BCSakhi  Transaction  Added Successfully');
   }
  
public function export_Shg_Transaction(Request $request){
    return Excel::download(new Export_ShgTransaction, 'Trasactions.xlsx');
}
   


}


