<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shg;
use App\Models\Shgtransaction;
use App\Imports\ShgTransactionImport;
use App\Imports\ShgImport;
use App\Exports\Export_ShgTransaction;

use Maatwebsite\Excel\Facades\Excel;
use DB;


class ShgController extends Controller
{
    //
    public function add_shg()
    {

        return view('shg.add-shg');
    }
    public function add_import_shg()
    {

        return view('shg.import-shg');
    }


    public function create(Request $request)
    {
        
           $shg = new Shg();  
           $shg->upload_month = $request->month;
           $shg->state = $request->state;
           $shg->district  = $request->district ;
           $shg->block  = $request->block;
           $shg->mclf = $request->mclf;
           $shg->clf_code = $request->clf_code;
           $shg->clf_name = $request->clf_name;
           $shg->da = $request->da;
           $shg->clf_bank  = $request->clf_bank ;
           $shg->clf_block  = $request->clf_block;
           $shg->clf_ifs_code  = $request->clf_ifs_code;
           $shg->clf_acc_no  = $request->clf_acc_no ;
           $shg->vo_name  = $request->vo_name ;
           $shg->vo_mis_code  = $request->vo_mis_code ;
           $shg->vo_bank  = $request->vo_bank ;
           $shg->vo_branch_name  = $request->vo_branch_name ;
           $shg->vo_ifs_code  = $request->vo_ifs_code ;
           $shg->vo_acc_no  = $request->vo_acc_no ;
           $shg->shg_name  = $request->shg_name ;
           $shg->shg_code  = $request->shg_code ;
           $shg->shg_bank = $request->shg_bank ;
           $shg->shg_branch  = $request->shg_branch ;
           $shg->shg_ifs_code  = $request->shg_ifs_code ;
           $shg->shg_acc_no = $request->shg_acc_no;
           $shg->bcsakhi_name  = $request->bcsakhi_name ;
           $shg->bcsakhi_bank  = $request->bcsakhi_bank ;
           $shg->bcsakhi_ifs_code = $request->bcsakhi_ifs_code ;
           $shg->bcsakhi_block  = $request->bcsakhi_block;
           $shg->bcsakhi_district  = $request->bcsakhi_district ;
           $shg->bcsakhi_contact = $request->bcsakhi_contact;
           $shg->Shortlisted_dual_auth_drive = $request->Shortlisted_dual_auth_drive;
           $shg->form_sbmtd_bank = $request->form_sbmtd_bank;
           $shg->clf_d_a_activated = $request->clf_d_a_activated;
           $shg->vo_d_a_activated = $request->vo_d_a_activated;
           $shg->shg_d_a_activated = $request->shg_d_a_activated;
           $shg->transaction_status = $request->transaction_status;
           $shg->remarks = $request->remarks;
           $shg->created_by = 111;
           $shg->save();
           return back()->with('status', 'SHG Added Successfully');
    }
    
    
    // public function shgimport(Request $request){
    //     // Define validation rules
    //     $rules = [
    //         'shgexcel' => 'required|mimes:xls,xlsx,csv',
    //     ];
    
    //     // Validate the request
    //     $request->validate($rules);
    
    //     // If the request passes validation, proceed with importing the Excel file
    //     Excel::import(new ShgImport, $request->file('shgexcel')->store('files'));
    
    //     return redirect()->back()->with('status', 'Data Imported successfully');
    // }
    public function shgimport(Request $request){
        // Define validation rules
        $rules = [
            'shgexcel' => 'required|mimes:xls,xlsx,csv',
        ];
    
        // Define custom validation messages
        $customMessages = [
            'shgexcel.required' => 'Please select an Excel file to upload.',
            'shgexcel.mimes' => 'Only Excel files with .xls or .xlsx ,csv extensions are allowed.',
        ];
    
        // Validate the request
        $request->validate($rules, $customMessages);
    
        // If the request passes validation, proceed with importing the Excel file
        Excel::import(new ShgImport, $request->file('shgexcel')->store('files'));
    
        return redirect()->back()->with('status', 'Data Imported successfully');
    }
    
    
    public function view_shg(Request $request){

$data=Shg::all();
        return view('shg.view-shg',compact('data'));
      }

   public function shg_transaction()
   {
    return view('shg.shg-transaction');
   }
   public function save(Request $request)
   {
       
          $shg = new Shgtransaction();  
          $shg->bcsakhi_id = 21;
          
          $shg->upload_month = $request->month;

          $shg->bc_sakhi = $request->bc_sakhi;
          $shg->new_enroll  = $request->new_enroll ;
          $shg->no_acc_verified_cbs  = $request->no_acc_verified_cbs;
          $shg->total_deposit_amt = $request->total_deposit_amt;
          $shg->deposit_total_transctn = $request->deposit_total_transctn;
          $shg->aeps_deposit_amt = $request->aeps_deposit_amt;
          $shg->aeps_total_transctn = $request->aeps_total_transctn;
          $shg->aeps_acquirer_amt  = $request->aeps_acquirer_amt ;
          $shg->acquirer_aeps_total_transctn  = $request->acquirer_aeps_total_transctn;
          $shg->shg_deposit_amt  = $request->shg_deposit_amt;
          $shg->total_shg_deposit_trans  = $request->total_shg_deposit_trans ;
          $shg->total_widrawl_amt  = $request->total_widrawl_amt ;
          $shg->total_no_withdral_trans  = $request->total_no_withdral_trans ;
          $shg->rupay_widrawl_amt  = $request->rupay_widrawl_amt ;
          $shg->no_rupay_widrawl_trans  = $request->no_rupay_widrawl_trans ;
          $shg->aeps_onus_widrawl_amt  = $request->aeps_onus_widrawl_amt ;
          $shg->no_aeps_onus_widrawl_trans  = $request->no_aeps_onus_widrawl_trans ;
          $shg->aeps_acq_widrawl_amt_of  = $request->aeps_acq_widrawl_amt_of ;
          $shg->no_aeps_acq_widrawl_trans_on  = $request->no_aeps_acq_widrawl_trans_on ;
          $shg->shg_widrawl_amt = $request->shg_widrawl_amt ;
          $shg->no_shg_widrawl_trans  = $request->no_shg_widrawl_trans ;
          $shg->t_f_t_amt  = $request->t_f_t_amt ;
          $shg->t_f_t_trans = $request->t_f_t_trans;
          $shg->aeps_fund_tnsfer_amt_on  = $request->aeps_fund_tnsfer_amt_on ;
          $shg->aeps_fund_tnsfer_trans_on  = $request->aeps_fund_tnsfer_trans_on ;
          $shg->aeps_acq_fund_tnsfer_amt_of = $request->aeps_acq_fund_tnsfer_amt_of ;
          $shg->aeps_acq_fund_tnsfer_trans_of  = $request->aeps_acq_fund_tnsfer_trans_of;
          $shg->i_m_t_amt  = $request->i_m_t_amt ;
          $shg->i_m_t_trans_no = $request->i_m_t_trans_no;
          $shg->shg_fund_tnsfr_amt = $request->shg_fund_tnsfr_amt;
          $shg->no_shg_fund_tnsfr_trans = $request->no_shg_fund_tnsfr_trans;
          $shg->pmjjy_cnt = $request->pmjjy_cnt;
          $shg->pmsby_cnt = $request->pmsby_cnt;
          $shg->cnt_sccess_uid = $request->cnt_sccess_uid;
          $shg->other_service = $request->other_service;
          $shg->total_txn_count = $request->total_txn_count;
          $shg->total_txn_amt = $request->total_txn_amt;   
       $shg->earng_bc = $request->earng_bc;

        //   $shg->created_by = 111;
          $shg->save();
          return back()->with('status', 'SHG Transaction  Added Successfully');
   }
   public function shgimport_transaction(Request $request){
    // dd("in");
    // Define validation rules
    $rules = [
        'shgTansaction' => 'required|mimes:xls,xlsx,csv',
    ];

    // Define custom validation messages
    $customMessages = [
        'shgTansaction.required' => 'Please select an Excel file to upload.',
        'shgTansaction.mimes' => 'Only Excel files with .xls or .xlsx ,csv extensions are allowed.',
    ];

    // Validate the request+
    $request->validate($rules, $customMessages);

    // If the request passes validation, proceed with importing the Excel file
    Excel::import(new ShgTransactionImport, $request->file('shgTansaction')->store('files'));

    return redirect()->back()->with('status', 'Data Imported successfully');
}
public function export_Shg_Transaction(Request $request){
    return Excel::download(new Export_ShgTransaction, 'Trasactions.xlsx');
}
   
}
