<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public  function bc_ranking()
    {
        return view('pages.bc-ranking');
    }
    public  function dist_bank_wise()
    {
        return view('pages.dist-bank-wise');
    }
    public  function dist_wise()
    {
        return view('pages.dist-wise');
    }
    public  function district_wise_table()
    {
        return view('pages.district-wise-table');
    }
    public  function iibf_certified()
    {
        return view('pages.iibf-certified');
    }
    public  function performance_analysis()
    {
        return view('pages.performance-analysis');
    }
    public  function shg_report()
    {
        return view('pages.shg-report');
    }
    public  function state_wise()
    {
        return view('pages.state-wise');
    }    
    public  function transaction_report()
    {
        return view('pages.transaction-report');
    }    
}
