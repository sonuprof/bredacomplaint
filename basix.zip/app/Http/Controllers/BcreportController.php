<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\bcsakhi;
use App\Models\Bcsakhitransaction;
use App\Imports\BCsakhitransactionImport;
use DB;
use Illuminate\Support\Carbon;

class BcreportController extends Controller
{

    
      public function dist_wise(Request $request)
    {

        $fromDate = $request->input('fromDate');
        $toDate = $request->input('toDate');
        $parsedFromDate = Carbon::parse($fromDate)->startOfDay();
        $parsedToDate = Carbon::parse($toDate)->endOfDay();

        $data['district'] = DB::table('bcsakhis')->distinct()->get('district');
        $data['bank'] =  DB::table('bcsakhis')->distinct()->get(['bank_name']);

        if ($request->isMethod('post')) {
            $res = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.district',
        'bcsakhitransactions.month',
        DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
        DB::raw('SUM(bcsakhitransactions.no_acc_verified_cbs) AS account_open'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS Active'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_amount'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) AS bcsakhi_count_txn'),
        DB::raw('SUM(bcsakhitransactions.pmjjy_cnt) AS pmjjy_cnt'),
        DB::raw('SUM(bcsakhitransactions.pmsby_cnt) AS pmsby_cnt'),
        DB::raw('SUM(bcsakhitransactions.other_service) AS other_service')
    )
    ->groupBy('bcsakhis.district', 'bcsakhitransactions.month');

            $district = $request->input('district');
            $block = $request->input('block');


            // Filter based on district
            $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate])->orWhere('bcsakhis.district', $district);

            if (!empty($block)) {
                $res->where('bcsakhis.block', $block);
            }


            // If month is selected, also filter based on month
            if (!empty($fromDate)) {
                if (!empty($toDate)) {
                
                $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate]);
                }
            }

            $data['query'] = $res->get();
            
        } else {

    $data['query'] = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.district',
        'bcsakhitransactions.month',
        DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
        DB::raw('SUM(bcsakhitransactions.no_acc_verified_cbs) AS account_open'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS Active'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_amount'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) AS bcsakhi_count_txn'),
        DB::raw('SUM(bcsakhitransactions.pmjjy_cnt) AS pmjjy_cnt'),
        DB::raw('SUM(bcsakhitransactions.pmsby_cnt) AS pmsby_cnt'),
        DB::raw('SUM(bcsakhitransactions.other_service) AS other_service')
    )
    ->groupBy('bcsakhis.district', 'bcsakhitransactions.month')
    ->get();
        }
        
        $data['total_txn_count'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
        $data['total_bc'] = DB::table('bcsakhis')->select('bc_type')->count();
        $data['bc_active'] = DB::table('bcsakhitransactions')
        ->where('total_txn_count', '>', 0)
        ->count();
        $data['total_txn_amt'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');

        return view('created.dist-wise', $data);
    }
    
    

    public function getBlocks($districtName)
    {
        $blocks = Bcsakhi::where('district', $districtName)
            ->distinct()
            ->pluck('block')
            ->toArray();
    
        return response()->json($blocks);
    }

  public function dist_bank_wise(Request $request)
    {

        // dd($request->all());
        $data['district'] = DB::table('bcsakhis')->distinct()->get('district');
        $fromDate = $request->input('fromDate');
        $toDate = $request->input('toDate');
        session(['selected_district3' => $request->input('district')]);
        session(['selected_month3' => $request->input('month')]);


        if ($request->isMethod('post')) {
            // dd("hi");
            $res = DB::table('bcsakhis')
            ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
            ->select(
                'bcsakhis.bank_name',
                DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
                DB::raw('SUM(IF(bcsakhitransactions.total_txn_count >= 1, 1, 0)) AS transacted_bcsakhi'),
                DB::raw('SUM(bcsakhitransactions.total_txn_count) AS total_transaction'),
                DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_transaction_amount'),
                DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
                DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) as Active'),
                DB::raw('(COUNT(bcsakhis.bank_name) / SUM(bcsakhitransactions.total_txn_count) * 100) AS percent_trans'),
                DB::raw('SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count) AS avg_txn'),
                DB::raw('SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count) AS avg_ticket'),
                DB::raw('(SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count)) * (SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count)) AS avg_transacted_agent'),
                DB::raw('SUM(bcsakhitransactions.earng_bc) / COUNT(bcsakhitransactions.total_txn_count) AS avg_commission_agent')
            )
            ->groupBy('bcsakhis.bank_name');

            $district = $request->input('district');
            $block = $request->input('block');


            // Filter based on district
            $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate])->orWhere('bcsakhis.district', $district);

            if (!empty($block)) {
                $res->where('bcsakhis.block', $block);
            }


            // If month is selected, also filter based on month
            if (!empty($fromDate)) {
                if (!empty($toDate)) {
                
                $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate]);
                }
            }

            $data['query'] = $res->get();
        } else {

            $data['query']  = DB::table('bcsakhis')
            ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
            ->select(
                'bcsakhis.bank_name',
                DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
                DB::raw('SUM(IF(bcsakhitransactions.total_txn_count >= 1, 1, 0)) AS transacted_bcsakhi'),
                DB::raw('SUM(bcsakhitransactions.total_txn_count) AS total_transaction'),
                DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_transaction_amount'),
                DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
                DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) as Active'),
                DB::raw('(COUNT(bcsakhis.bank_name) / SUM(bcsakhitransactions.total_txn_count) * 100) AS percent_trans'),
                DB::raw('SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count) AS avg_txn'),
                DB::raw('SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count) AS avg_ticket'),
                DB::raw('(SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count)) * (SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count)) AS avg_transacted_agent'),
                DB::raw('SUM(bcsakhitransactions.earng_bc) / COUNT(bcsakhitransactions.total_txn_count) AS avg_commission_agent')
            )
            ->groupBy('bcsakhis.bank_name')
            ->get();
        }
        
           $data['total_txn_count'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
        $data['total_bc'] = DB::table('bcsakhis')->select('bc_type')->count();
        $data['bc_active'] = DB::table('bcsakhitransactions')
        ->where('total_txn_count', '>', 0)
        ->count();
        $data['total_txn_amt'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');
        $data['earning_bc'] = DB::table('bcsakhitransactions')->sum('earng_bc');
        return view('created.dist-bank-wise', $data);
    }

    public function state_wise(Request $request)
    {
        //  dd($request->all());

        $fromDate = $request->input('fromDate');
        $toDate = $request->input('toDate');
        // dd( $parsedFromDate);
        if ($request->isMethod('post')) {
            

        $res  = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.bank_name',
        DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS transacted_bcsakhi'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) AS total_transaction'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_transaction_amount'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS Active'),
        DB::raw('(COUNT(bcsakhis.bank_name) / SUM(bcsakhitransactions.total_txn_count) * 100) AS percent_trans'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count) AS avg_txn'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count) AS avg_ticket'),
        DB::raw('(SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count)) * (SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count)) AS avg_transacted_agent'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) / COUNT(bcsakhitransactions.total_txn_count) AS avg_commission_agent')
    )
    ->groupBy('bcsakhis.bank_name');
    

            // Filter based on district
            $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate]);

            $data['query'] = $res->get();
            
            }
            else{
                
                
     $data['query']   = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.bank_name',
        DB::raw('COUNT(bcsakhis.name) AS bcsakhi_count'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS transacted_bcsakhi'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) AS total_transaction'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) AS total_transaction_amount'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) AS commission'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count > 0, 1, 0)) AS Active'),
        DB::raw('(COUNT(bcsakhis.bank_name) / SUM(bcsakhitransactions.total_txn_count) * 100) AS percent_trans'),
        DB::raw('SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count) AS avg_txn'),
        DB::raw('SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count) AS avg_ticket'),
        DB::raw('(SUM(bcsakhitransactions.total_txn_count) / COUNT(bcsakhitransactions.total_txn_count)) * (SUM(bcsakhitransactions.total_txn_amt) / SUM(bcsakhitransactions.total_txn_count)) AS avg_transacted_agent'),
        DB::raw('SUM(bcsakhitransactions.earng_bc) / COUNT(bcsakhitransactions.total_txn_count) AS avg_commission_agent')
    )
    ->groupBy('bcsakhis.bank_name')
    ->get();
            }
        return view('created.state-wise', $data);
    }



  public function iibf_certified(Request $request)
    {

        $data['district'] = DB::table('bcsakhis')->distinct()->get('district');
        $fromDate = $request->input('fromDate');
        $toDate = $request->input('toDate');
        session(['selected_district4' => $request->input('district')]);
        session(['selected_month4' => $request->input('month')]);
        
        
        $res = DB::table('bcsakhis')
    ->select(
        'district',
        DB::raw('COUNT(name) AS count_bc'),
        DB::raw('SUM(IF(iibf_certificate = "Y", 1, 0)) AS iibf_certified'),
        DB::raw('SUM(IF(machine_id = "-", 1, 0)) AS not_onboard'),
        DB::raw('SUM(IF(machine_id != "-", 1, 0)) AS onboard')
    )
    ->groupBy('district');


        if ($request->isMethod('post')) {


            $district = $request->input('district');
            $block = $request->input('block');


            // Filter based on district
            $res->Where('bcsakhis.district', $district);

            if (!empty($block)) {
                $res->where('bcsakhis.block', $block);
            }


            $data['query'] = $res->get();
        } else {
            // dd("if else ");

            $data['query'] =  DB::table('bcsakhis')
    ->select(
        'district',
        DB::raw('COUNT(name) AS count_bc'),
        DB::raw('SUM(IF(iibf_certificate = "Y", 1, 0)) AS iibf_certified'),
        DB::raw('SUM(IF(machine_id = "-", 1, 0)) AS not_onboard'),
        DB::raw('SUM(IF(machine_id != "-", 1, 0)) AS onboard')
    )
    ->groupBy('district')
    ->get();
        }
        return view('created.iibf-certified', $data);
    }



 public function transaction_report(Request $request)
    {

     $data['district'] = DB::table('bcsakhis')->distinct()->get('district');
        $fromDate = $request->input('fromDate');
        $toDate = $request->input('toDate');
        session(['selected_district3' => $request->input('district')]);
        session(['selected_month3' => $request->input('month')]);

        // dd($request->input('month'));
        if ($request->isMethod('post')) {
            
            $res = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.district',
        DB::raw('COUNT(bcsakhis.name) AS count_bc'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count = 0, 1, 0)) AS total_trans1'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 1 AND 99, 1, 0)) AS total_trans2'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 100 AND 199, 1, 0)) AS total_trans3'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 200 AND 249, 1, 0)) AS total_trans4'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count >= 250, 1, 0)) AS total_trans5')
    )
    ->where('bcsakhitransactions.total_txn_count', '>=', 0) // Optionally filter out records where total_txn_count is less than 0
    ->groupBy('bcsakhis.district');
    
    
            $district = $request->input('district');
            $block = $request->input('block');


            // Filter based on district
            $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate])->orWhere('bcsakhis.district', $district);

            if (!empty($block)) {
                $res->where('bcsakhis.block', $block);
            }


            // If month is selected, also filter based on month
            if (!empty($fromDate)) {
                if (!empty($toDate)) {
                
                $res->whereBetween('bcsakhitransactions.month', [$fromDate,  $toDate]);
                }
            }

            $data['query'] = $res->get();
        } else {

            $data['query'] = DB::table('bcsakhis')
    ->join('bcsakhitransactions', 'bcsakhis.id', '=', 'bcsakhitransactions.bcsakhi_id')
    ->select(
        'bcsakhis.district',
        DB::raw('COUNT(bcsakhis.name) AS count_bc'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count = 0, 1, 0)) AS total_trans1'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 1 AND 99, 1, 0)) AS total_trans2'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 100 AND 199, 1, 0)) AS total_trans3'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count BETWEEN 200 AND 249, 1, 0)) AS total_trans4'),
        DB::raw('SUM(IF(bcsakhitransactions.total_txn_count >= 250, 1, 0)) AS total_trans5')
    )
    ->where('bcsakhitransactions.total_txn_count', '>=', 0) // Optionally filter out records where total_txn_count is less than 0
    ->groupBy('bcsakhis.district')
    ->get();
        }
        return view('created.transaction-report', $data);
    }


public function Graph(Request $request){
$data['enroll']  = DB::table('bcsakhitransactions')->sum('new_enroll');
$data['bank'] = bcsakhi::select('bank_name', DB::raw('COUNT(name) as bc_sakhi'))->where('model', 'KIOSK')
->groupBy('bank_name')->get(); 
$data['total_txn_amt'] = DB::table('bcsakhitransactions')->sum('total_txn_amt');
$data['total_txn_count'] = DB::table('bcsakhitransactions')->sum('total_txn_count');
$data['earning_bc'] = DB::table('bcsakhitransactions')->sum('earng_bc');
$data['dist_bank']  = DB::select("SELECT `bcsakhis`.`bank_name`, count(name) AS bcsakhi_count, SUM(IF(total_txn_count >= '1',1,0)) AS transacted_bcsakhi,SUM(bcsakhitransactions.total_txn_count) AS total_transaction, SUM(bcsakhitransactions.total_txn_amt) AS total_transaction_amount, SUM(bcsakhitransactions.earng_bc) AS commission , SUM(IF(`bcsakhitransactions`.`total_txn_count`> 0,1,0)) as Active, (COUNT(`bcsakhis`.`bank_name`)/ SUM(bcsakhitransactions.total_txn_count) * 100 ) AS percent_trans,(SUM(bcsakhitransactions.total_txn_count)/COUNT(bcsakhitransactions.total_txn_count)) AS avg_txn, (SUM(bcsakhitransactions.total_txn_amt)/SUM(bcsakhitransactions.total_txn_count)) AS avg_ticket,
((SUM(bcsakhitransactions.total_txn_count)/COUNT(bcsakhitransactions.total_txn_count)) * (SUM(bcsakhitransactions.total_txn_amt)/SUM(bcsakhitransactions.total_txn_count))) AS avg_transacted_agent,
(SUM(bcsakhitransactions.earng_bc)/COUNT(bcsakhitransactions.total_txn_count)) AS avg_commission_agent
FROM `bcsakhis`,`bcsakhitransactions` WHERE  `bcsakhis`.`id` = `bcsakhitransactions`.`bcsakhi_id` GROUP BY `bcsakhis`.`bank_name`");
return view('graph.graphs', $data);

}
}
