<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\DB;

class Export_ShgTransaction implements FromCollection, WithHeadings
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        // Retrieve the data you want to export
        $data = DB::table('bcsakhis')->select('id', 'name')->get();

        // You need to return the data as a collection
        return $data;
    }

    public function headings(): array
    {
        return [
            'ID',
            'BC_SAKHI',
            'NEW ENROLLMENTS',
            'NO OF ACCOUNTS VERIFIED ON CBS',
            'TOTAL DEPOSIT AMOUNT (RS)',
            'TOTAL NO. OF DEPOSIT TRANSACTION',
            'AEPS (ONUS) DEPOSIT AMOUNT (RS)',
            'NO. OF AEPS (ONUS) DEPOSIT TRANSACTION',
            'AEPS (OFFUS) ACQUIRER DEPOSIT AMOUNT (RS)',
            'NO. OF AEPS (OFFUS) ACQUIRER DEPOSIT',
            'SHG DEPOSIT AMOUNT (RS)',
            'NO. OF SHG DEPOSIT TRANSACTIONS',
            'TOTAL WITHDRAWAL AMOUNT (RS)',
            'TOTAL NO. OF WITHDRAWAL TRANSACTIONS',
            'RUPAY WITHDRAWAL AMOUNT',
            'NO. OF RUPAY WITHDRAWAL TRANSACTIONS',
            'AEPS (ONUS) WITHDRAWAL AMOUNT (RS)',
            'NO. OF TRANSACTION AEPS (ONUS) WITHDRAWAL',
            'AEPS (OFFUS) ACQUIRER WITHDRAWAL AMOUNT (RS)',
            'NO. OF AEPS (OFFUS) ACQUIRER WITHDRAWAL TRANSACTIONS',
            'SHG WITHDRAWAL AMOUNT',
            'NO. OF SHG WITHDRAWAL TRANSACTIONS',
            'TOTAL FUNDS TRANSFER AMOUNT (RS)',
            'TOTAL NO. OF FUNDS TRANSFER TRANSACTIONS',
            'AEPS (ONUS) FUND TRANSFER AMOUNT (RS)',
            'NO. OF AEPS (ONUS) FUND TRANSFER TRANSACTIONS',
            'AEPS (OFFUS) ACQUIRER FUNDS TRANSFER AMOUNT (RS)',
            'NO. OF AEPS (OFFUS) ACQUIRER FUNDS TRANSFER TRANSACTIONS',
            'INTERSOL MONEY TRANSFER AMOUNT (RS)',
            'NO. OF INTERSOL MONEY TRANSFER TRANSACTIONS',
            'SHG FUNDS TRANSFER AMOUNT',
            'NO. OF SHG FUNDS TRANSFER TRANSACTIONS',
            'PMJJBY COUNT',
            'PMSBY COUNT',
            'COUNT OF SUCCESS UID SEEDING',
            'ANY OTHER SERVICE (NUMBERS) ',
            'TOTAL TXN COUNT..',
            'TOTAL TXN AMOUNT',
            'CUMULATIVE EARNING OF BC/BANK SAKHI',
        ];
    }
}
