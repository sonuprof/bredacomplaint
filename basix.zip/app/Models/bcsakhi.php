<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class bcsakhi extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'upload_month',
        'name',
        'designation',
        'contact',
        'parent_shg',
        'village',
        'bank_name',
        'branch_name',
        'branch_code',
        'block',
        'block_type',
        'district',
        'corporate_bc',
        'agent_id',
        'date_code_creation',
        'iibf_certificate',
        'model',
        'machine_id',
        'no_village',
        'no_shg',
        'od_limit',
        'settlement_account',
        'created_by',
        'date',
      
    ];
}
