<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shg extends Model
{
    use HasFactory;
    protected $fillable=[ 
        'state',
         'district',
          'block',
           'mclf',
    'clf_code', 
    'clf_name',
     'da',
      'clf_bank',
       'clf_block', 
       'clf_ifs_code',
        'clf_acc_no',
         'vo_name',
      'vo_mis_code', 'vo_bank', 'vo_branch_name', 'vo_ifs_code', 'vo_acc_no', 'shg_name', 'shg_code',
       'shg_bank', 'shg_branch', 'shg_ifs_code', 'shg_acc_no', 'bcsakhi_name', 'bcsakhi_bank',
        'bcsakhi_ifs_code', 'bcsakhi_block', 'bcsakhi_district', 'bcsakhi_contact', 
        'Shortlisted_dual_auth_drive', 'form_sbmtd_bank', 'clf_d_a_activated', 'vo_d_a_activated', 
        'shg_d_a_activated', 'transaction_status', 'remarks',  'created_by'];
}