<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shgtransaction extends Model
{
    use HasFactory;
    protected $fillable=[ 
        'bcsakhi_id',
         'bc_sakhi',
          'new_enroll',
           'no_acc_verified_cbs',
    'total_deposit_amt', 
    'deposit_total_transctn',
     'aeps_deposit_amt',
      'aeps_total_transctn',
       'aeps_acquirer_amt', 
       'acquirer_aeps_total_transctn',
        'no_aeps_acq_widrawl_trans_on',
         'total_shg_deposit_trans',
      'total_widrawl_amt',
       'total_no_withdral_trans', 
       'rupay_widrawl_amt', 'no_rupay_widrawl_trans', 
       'aeps_onus_widrawl_amt', 
       'no_aeps_onus_widrawl_trans',
        'aeps_acq_widrawl_amt_of',
       'no_aeps_acq_widrawl_trans_on',
        'no_shg_widrawl_trans', 
        't_f_t_amt', 
        't_f_t_trans',
         'aeps_fund_tnsfer_amt_on',
          'aeps_fund_tnsfer_trans_on',
        'aeps_acq_fund_tnsfer_amt_of',
         'aeps_acq_fund_tnsfer_trans_of',
          'i_m_t_amt', 
          'i_m_t_trans_no', 
        'shg_fund_tnsfr_amt',
         'no_shg_fund_tnsfr_trans',
          'pmjjy_cnt', 
          'pmsby_cnt', 
        'cnt_sccess_uid', 
        'other_service', 
        'total_txn_count',
          'total_txn_amt',
          'total_txn_amt',
          'earng_bc'];
}
