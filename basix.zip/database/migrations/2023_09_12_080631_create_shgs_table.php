<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('shgs', function (Blueprint $table) {
            $table->id();

            $table->string('state')->nullable();
            $table->string('district')->nullable();
            $table->string('block')->nullable();
            $table->string('mclf')->nullable();
            $table->string('clf_code')->nullable();
            $table->string('clf_name')->nullable();
            $table->string('da')->nullable();
            $table->string('clf_bank')->nullable();
            $table->string('clf_block')->nullable();
            $table->string('clf_ifs_code')->nullable();
            $table->string('clf_acc_no')->nullable();
             $table->string('vo_name')->nullable();
            $table->string('vo_mis_code')->nullable();
            $table->string('vo_bank')->nullable();
            $table->string('vo_branch_name')->nullable(); 
            $table->string('vo_ifs_code')->nullable();
            $table->string('vo_acc_no')->nullable();
            $table->string('shg_name')->nullable();
            $table->string('shg_code')->nullable();
            $table->string('shg_bank')->nullable();
            $table->string('shg_branch')->nullable();
            $table->string('shg_ifs_code')->nullable();
            $table->string('shg_acc_no')->nullable();
            $table->string('bcsakhi_name')->nullable();
            $table->string('bcsakhi_bank')->nullable();
            $table->string('bcsakhi_ifs_code')->nullable();
            $table->string('bcsakhi_block')->nullable();
            $table->string('bcsakhi_district')->nullable();
            $table->string('bcsakhi_contact')->nullable();
            $table->string('Shortlisted_dual_auth_drive')->nullable();
            $table->string('form_sbmtd_bank')->nullable();
            $table->string('clf_d_a_activated')->nullable();
            $table->string('vo_d_a_activated')->nullable();
            $table->string('shg_d_a_activated')->nullable();
            $table->string('transaction_status')->nullable();
            $table->string('remarks')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('shgs');
    }
};
