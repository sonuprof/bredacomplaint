<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bcsakhitransactions', function (Blueprint $table) {
            $table->id();
            $table->string('bc_sakhi')->nullable();
            $table->string('new_enroll')->nullable();
            $table->string('no_acc_verified_cbs')->nullable();
            $table->string('total_deposit_amt')->nullable();
            $table->string('deposit_total_transctn')->nullable();
            $table->string('aeps_deposit_amt')->nullable();
            $table->string('aeps_total_transctn')->nullable();
            $table->string('aeps_acquirer_amt')->nullable();
            $table->string('acquirer_aeps_total_transctn')->nullable();
            $table->string('shg_deposit_amt')->nullable();
            $table->string('total_shg_deposit_trans')->nullable();
            $table->string('total_widrawl_amt')->nullable();
            $table->string('total_no_withdral_trans')->nullable();
            $table->string('rupay_widrawl_amt')->nullable();
            $table->string('no_rupay_widrawl_trans')->nullable();
            $table->string('aeps_onus_widrawl_amt')->nullable();
            $table->string('no_aeps_onus_widrawl_trans')->nullable();
            $table->string('aeps_acq_widrawl_amt_of')->nullable();
            $table->string('no_aeps_acq_widrawl_trans_on')->nullable();
            $table->string('shg_widrawl_amt')->nullable();
            $table->string('no_shg_widrawl_trans')->nullable();
            $table->string('t_f_t_amt')->nullable();
            $table->string('t_f_t_trans')->nullable();
            $table->string('aeps_fund_tnsfer_amt_on')->nullable();
            $table->string('aeps_fund_tnsfer_trans_on')->nullable();
            $table->string('aeps_acq_fund_tnsfer_amt_of')->nullable();
            $table->string('aeps_acq_fund_tnsfer_trans_of')->nullable();
            $table->string('i_m_t_amt')->nullable();
            $table->string('i_m_t_trans_no')->nullable();
            $table->string('shg_fund_tnsfr_amt')->nullable();
            $table->string('no_shg_fund_tnsfr_trans')->nullable();
            $table->string('pmjjy_cnt')->nullable();
            $table->string('pmsby_cnt')->nullable();
            $table->string('cnt_sccess_uid')->nullable();
            $table->string('other_service')->nullable();
            $table->string('total_txn_count')->nullable();
            $table->string('total_txn_amt')->nullable();
            $table->string('earng_bc')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bcsakhitransactions');
    }
};
